package com.rvdv.cross.abac.security.sampleattributeprotection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleAttributeProtectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
